package com.example.truco_full

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

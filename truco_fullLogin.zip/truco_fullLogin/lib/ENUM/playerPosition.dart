enum PlayerPosition {
  top,
  bottom
}
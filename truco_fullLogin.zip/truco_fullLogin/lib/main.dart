import 'package:flutter/material.dart';
import 'screens/BoardPage.dart'; // Importe o arquivo onde está a classe BoardPage
import 'screens/loginscreen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Truco',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home:
          LoginScreen(), // Defina BoardPage como a tela inicial do seu aplicativo
    );
  }
}

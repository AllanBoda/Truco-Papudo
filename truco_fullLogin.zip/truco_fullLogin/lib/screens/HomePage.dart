import 'package:flutter/material.dart';
import 'boardpage.dart';
import '../screensService/auth_service.dart';

class HomePage extends StatelessWidget {
  final AuthService authService;

  const HomePage({Key? key, required this.authService}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Bem-vindo, ${authService.loggedInUser}!',
              style: TextStyle(fontSize: 24.0),
            ),
            const SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const BoardPage()),
                );
              },
              child: const Text('Começar Jogo'),
            ),
          ],
        ),
      ),
    );
  }
}

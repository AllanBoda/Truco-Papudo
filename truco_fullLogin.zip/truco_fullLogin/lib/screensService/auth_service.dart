class AuthService {
  String? loggedInUser;

  void register(String username, String password) {
    loggedInUser = username;
  }

  bool login(String username, String password) {
    if (loggedInUser == username) {
      return true;
    }
    return false;
  }
}
